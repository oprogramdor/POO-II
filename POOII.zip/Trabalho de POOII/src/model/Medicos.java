package model;

public class Medicos {

    int id_medicos;
    String nome_medicos; 
    String crm_medicos;
    String especialidade_medicos;
    double salario_medicos;

    public String getCrm_medicos() {
        return crm_medicos;
    }

    public void setCrm_medicos(String crm_medicos) {
        this.crm_medicos = crm_medicos;
    }

    public String getEspecialidade_medicos() {
        return especialidade_medicos;
    }

    public void setEspecialidade_medicos(String especialidade_medicos) {
        this.especialidade_medicos = especialidade_medicos;
    }

    public double getSalario_medicos() {
        return salario_medicos;
    }

    public void setSalario_medicos(double salario_medicos) {
        this.salario_medicos = salario_medicos;
    }

    public int getId_medicos() {
        return id_medicos;
    }

    public void setId_medicos(int id_medicos) {
        this.id_medicos = id_medicos;
    }

    public String getNome_medicos() {
        return nome_medicos;
    }

    public void setNome_medicos(String nome_medicos) {
        this.nome_medicos = nome_medicos;
    }

    public void setString(int i, String valueOf) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
